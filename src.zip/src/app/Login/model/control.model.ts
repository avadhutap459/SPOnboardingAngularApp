export class control{
    id : number;
    name:string;
    value:string;
}